package br.com.alura.funcionarios.api.swagger.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
//    Configurando classe para o swagger no spring

@EnableSwagger2
//   Ativando a configuração do swagger nesse contexto

//O select Auxilia no biuld da documentação interativa

public class SwaggerConfiguration {
	
	@Bean
	 public Docket api() {
		return new Docket(DocumentationType.SWAGGER_2)
		.select()
		.apis(RequestHandlerSelectors.basePackage("br.com.alura.funcionarios.api"))
		.build()
		.apiInfo(getApiInfo());    
    }

	// Criador do objeto Info
	private ApiInfo getApiInfo() {
		return new ApiInfoBuilder() 
				.title("Funcionários API")
				.description("Esta API faz o cadastro, consulta, alteração e exclusão de funcionários")
				.contact(new Contact("Wesley Rocha - Curso da Alura - Swagger Parte 2", "https://cursos.alura.com.br/course/swagger-customize-e-documente-uma-api-existente", "wesleyrocha.ti@gmail.com"))
				.version("1.0.0")
				.build();
	}
}

